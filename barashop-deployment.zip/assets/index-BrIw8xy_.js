(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=[{id:`hong-do-naomi`,name:`Hoa hồng đỏ Naomi`,color:`Đỏ đậm`,price:null,currency:`JPY`,availability:`preorder`,stock:0,leadTime:`Đặt trước: thời gian giao sẽ xác nhận sau`,featured:!0,description:`Hoa hồng đỏ sang trọng, phù hợp làm quà tặng lãng mạn và các dịp đặc biệt tại Nhật.`,images:[`/images/hong-do-naomi.png`],paymentMethods:[`PayPay`,`COD`]}],t=document.querySelector(`#roseGrid`),n=document.querySelector(`#roseSelect`),r=document.querySelector(`#checkoutForm`),i=document.querySelector(`#formStatus`);document.querySelector(`#year`).textContent=new Date().getFullYear();var a={preorder:`Preorder`,limited_stock:`Còn ít`,sold_out:`Tạm hết`};function o(e){return e.price?`${e.price.toLocaleString(`ja-JP`)} ${e.currency}`:`Giá xác nhận sau`}t.innerHTML=e.map(e=>`
  <article class="rose-card">
    <img src="${e.images?.[0]||`/images/hong-do-naomi.png`}" alt="${e.name}" />
    <div class="rose-body">
      <div class="rose-meta">
        <span>${e.color}</span>
        <strong>${a[e.availability]||e.availability}</strong>
      </div>
      <h3>${e.name}</h3>
      <p>${e.description}</p>
      <div class="rose-footer">
        <span>${o(e)}</span>
        <small>${e.leadTime}</small>
      </div>
    </div>
  </article>
`).join(``),n.innerHTML=e.map(e=>`<option value="${e.id}">${e.name} — ${o(e)}</option>`).join(``),r.addEventListener(`submit`,async e=>{e.preventDefault(),i.textContent=`Đang gửi đơn...`;let t=Object.fromEntries(new FormData(r).entries());t.quantity=Number(t.quantity||1);try{let e=await fetch(`/api/checkout`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)}),n=await e.json().catch(()=>({}));if(!e.ok)throw Error(n.error||`Không gửi được đơn.`);r.reset(),i.textContent=`Đã gửi đơn. Barashop sẽ liên hệ xác nhận sớm.`}catch(e){i.textContent=`Lỗi: ${e.message}`}});